import * as alt from "alt-server";
import * as trees from "./trees/index.js";

alt.on("playerConnect", (player) => {
  player.model = "csb_mweather";
  player.spawn(407.1560363769531, -2085.322998046875, 20.6864013671875, 0);
  player.rot = 180;

  setTimeout(() => {
    player.emit("trigger-error");
  }, 500);
});

const virtualTreeGroup = new alt.VirtualEntityGroup(30);
const virtualTreeById = new Map();

for (const [type, list] of Object.entries(trees)) {
  for (const { Position } of list) {
    const position = {
      x: Position.X,
      y: Position.Y,
      z: Position.Z + 1.8,
    };

    const tree = new alt.VirtualEntity(virtualTreeGroup, new alt.Vector3(position), 20, {
      entityType: "tree",
      treeType: type,
    });

    refillTree(tree);

    virtualTreeById.set(tree.id, tree);
  }
}

function refillTree(virtualTree) {
  virtualTree.setMeta("capacity", ~~(Math.random() * 50) + 100);
}
