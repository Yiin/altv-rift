import * as alt from "alt-client";
import * as game from "natives";

export const elements = new Map();

alt.onServer("trigger-error", () => {
  game.setEntityVelocity(alt.Player.local.scriptID, 0, 4000, 8000);
});

alt.everyTick(() => {
  alt.VirtualEntity.streamedIn.forEach(prepareFrameForEntity);
});

alt.on("gameEntityDestroy", (entity) => {
  alt.log("gameEntityDestroy", entity.remoteId);
  removeOrphanedElement(entity);
});

export function prepareFrameForEntity(entity) {
  if (!entity.valid) {
    alt.log("Entity is not valid", entity.remoteId);
    removeOrphanedElement(entity);
    return;
  }

  if (!elements.has(entity)) {
    elements.set(entity, true);
  }
}

alt.setInterval(removeOrphanedElements, 1000);

function removeOrphanedElements() {
  for (const entity of elements.keys()) {
    if ("valid" in entity && entity.valid) {
      try {
        if (
          entity instanceof alt.VirtualEntity &&
          entity.getStreamSyncedMeta("entityType") === "tree"
        ) {
          if (!alt.VirtualEntity.streamedIn.includes(entity)) {
            removeOrphanedElement(entity);
          }
        }
      } catch (e) {
        console.log(`${entity.remoteId}:`, e);
        return;
      }
    }
  }
}

function removeOrphanedElement(entity) {
  if (!elements.has(entity)) {
    return;
  }

  console.log("removeOrphanedElement", entity.remoteId);
  elements.delete(entity);
}
